//
//  AlarmTableViewController.swift
//  MotionAlarm
//
//  Created by strivin on 2020/12/12.
//

import UIKit
import os.log

class AlarmTableViewController: UITableViewController {
//MARK:-properties
    var alarms = [AlarmData]() // 所有商品组成的数组
//MARK:-override funcs
    override func viewDidLoad() {
        super.viewDidLoad()

        registerNotification()
        
        // 左上角键为编辑键
        self.navigationItem.leftBarButtonItem = editButtonItem
        // 首次打开APP，将加载示例闹钟
        if let initAlarms = loadAlarms() {
            alarms += initAlarms
        }
        else {
            alarms += loadSampleAlarms()!
        }
        
        updateAlarms()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        switch(segue.identifier ?? ""){
        // 添加新闹钟，无需设置
        case "addAlarm":
            os_log("Adding a new item.", log: OSLog.default, type: .debug)
        // 显示已有闹钟，需要设置
        case "setAlarm":
            // 找到目标视图控制器
            guard let alarmSettingViewController = segue.destination as? AlarmSettingViewController else{
                fatalError("Unexpected destination: \(segue.destination)")
            }
            // 找到被选cell
            guard let selectedCell = sender as? AlarmTableViewCell else{
                fatalError("Unexpected sender: \(String(describing: sender))")
            }
            // 找到被选cell的indexPath
            guard let indexPath = tableView.indexPath(for: selectedCell) else{
                fatalError("The selected cell is not being displayed by the table")
            }
            
            alarmSettingViewController.alarm = alarms[indexPath.row]
            
        default:
            fatalError("Unexpected Segue Identifier; \(String(describing: segue.identifier))")
        }
    }
    @IBAction func unwindToTableView(sender:UIStoryboardSegue){
        if let alarmSettingViewController = sender.source as? AlarmSettingViewController, let alarm = alarmSettingViewController.alarm{
            // 更新已有闹钟
            if let indexPath = tableView.indexPathForSelectedRow{
                alarms[indexPath.row] = alarm
                tableView.reloadRows(at: [indexPath], with: .none)
            }
            // 添加新闹钟
            else{
                let newIndexPath = IndexPath(row: alarms.count, section: 0)
                alarms.append(alarm)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
            updateAlarms()
            saveAlarms()
        }
    }
    @IBAction func unwindFromMotion(sender:UIStoryboardSegue){
    }
// MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return alarms.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AlarmTableViewCell", for: indexPath) as? AlarmTableViewCell else{
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }
        
        let row = indexPath.row
        cell.setAlarm(alarms[row])

        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            func closureDeleteAction(_ action:UIAlertAction){
                alarms.remove(at: indexPath.row)
                saveAlarms()
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
            
            let alert = UIAlertController(title: "Delete Item", message: "Are you sure to delete this item?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: closureDeleteAction))
            present(alert, animated: true, completion: nil)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
//MARK:-other funcs
    private func loadSampleAlarms()->[AlarmData]?{
        // 示例闹钟1
        let sample1_alarmDate = Date.init(timeIntervalSinceNow: 300)
        let sample1_tipText = "morning"
        let sample1_alarmOn = true
        let sample1_week = 0
        let sample1_mode = "chop"
        let sample1_times = 40
        let sample1_identifier = sample1_alarmDate.description
        let sample1_alarm = AlarmData(alarmDate: sample1_alarmDate, tipText: sample1_tipText, alarmOn: sample1_alarmOn, week: sample1_week,mode:sample1_mode,times:sample1_times, identifier: sample1_identifier)
        // 示例闹钟2
        let sample2_alarmDate = Date.init(timeIntervalSinceNow: 600)
        let sample2_tipText = "night"
        let sample2_alarmOn = false
        let sample2_week = 127
        let sample2_mode = "drive"
        let sample2_times = 50
        let sample2_identifier = sample2_alarmDate.description
        let sample2_alarm = AlarmData(alarmDate: sample2_alarmDate, tipText: sample2_tipText, alarmOn: sample2_alarmOn, week: sample2_week,mode:sample2_mode,times:sample2_times, identifier: sample2_identifier)
        
        var sample_alarms = [AlarmData]()
        sample_alarms.append(sample1_alarm)
        sample_alarms.append(sample2_alarm)
        
        return sample_alarms
    }
    private func loadAlarms()->[AlarmData]?{
        return NSKeyedUnarchiver.unarchiveObject(withFile: AlarmData.ArchiveURL.path) as? [AlarmData]
    }
    private func saveAlarms(){
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(alarms, toFile: AlarmData.ArchiveURL.path)
        
        if isSuccessfulSave {
            os_log("Items successfully saved.", log: OSLog.default, type: .debug)
        } else {
            os_log("Failed to save items...", log: OSLog.default, type: .error)
        }
    }
    func registerNotification(){
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            
            // Enable or disable features based on the authorization.
        }
    }
    func updateAlarms(){
        for alarm in alarms{
            alarm.setTabel(self)
            if alarm.alarmOn{
                alarm.turnOnAlarm()
            }
            else{
                alarm.turnOffAlarm()
            }
        }
    }
}
