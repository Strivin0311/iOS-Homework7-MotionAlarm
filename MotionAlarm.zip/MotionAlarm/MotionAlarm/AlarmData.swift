//
//  AlarmData.swift
//  MotionAlarm
//
//  Created by strivin on 2020/12/13.
//

import UIKit

class AlarmData:NSObject,NSCoding{
//MARK: -var
    var alarmDate:Date? // 闹钟时间
    var tipText:String? // 闹钟提示
    var alarmOn:Bool = false // 闹钟是否开启
    var week:Int // 星期重复(7位二进制数，0表示不重复，即只响一次)
    var mode:String? // 运动模式
    var times:Int // 运动时间
    var identifier: String? // 通知标识
    var table:AlarmTableViewController? = nil
    var timers = [Timer]()
//MARK:-static
    struct PropertyKey{ // 文件读写属性键
        static let alarmDate = "alarmDate"
        static let tipText = "tipText"
        static let alarmOn = "alarmOn"
        static let week = "week"
        static let mode = "mode"
        static let times = "times"
        static let identifier = "identifier"
    }
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first! // 文件读写路径
    
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("MotionAlarm") // 文件URL
//MARK:-init funcs
    init(alarmDate:Date?, tipText:String?,alarmOn:Bool,week:Int,mode:String?,times:Int,identifier:String?){
        if let date = alarmDate{
            self.alarmDate = date
        }else{
            self.alarmDate = Date()
        }
        
        if let text = tipText{
            self.tipText = text
        }else{
            self.tipText = "alarm"
        }
        
        self.alarmOn = alarmOn
        self.week = week
        
        if let mode = mode{
            self.mode = mode
        }else{
            self.mode = "chop"
        }
        self.times = times
        
        if let id = identifier{
            self.identifier = id
        }else{
            self.identifier = Date(timeIntervalSinceNow: 0).description
        }
        for _ in 0...6{
            self.timers.append(Timer())
        }
    }
    required convenience init?(coder : NSCoder){
        let alarmDate = coder.decodeObject(forKey: PropertyKey.alarmDate) as? Date
        let tipText = coder.decodeObject(forKey: PropertyKey.tipText) as? String
        let alarmOn = coder.decodeBool(forKey: PropertyKey.alarmOn) as Bool
        let week = coder.decodeInteger(forKey: PropertyKey.week)
        let mode = coder.decodeObject(forKey: PropertyKey.mode) as? String
        let times = coder.decodeInteger(forKey: PropertyKey.times)
        let identifier = coder.decodeObject(forKey: PropertyKey.identifier) as? String
        
        self.init(
            alarmDate:alarmDate,
            tipText:tipText,
            alarmOn:alarmOn,
            week:week,
            mode:mode,
            times:times,
            identifier:identifier
        )
    }
//MARK:-other funcs
    func encode(with coder:NSCoder){
        coder.encode(alarmDate,forKey: PropertyKey.alarmDate)
        coder.encode(tipText,forKey: PropertyKey.tipText)
        coder.encode(alarmOn,forKey: PropertyKey.alarmOn)
        coder.encode(week,forKey: PropertyKey.week)
        coder.encode(mode,forKey: PropertyKey.mode)
        coder.encode(times,forKey: PropertyKey.times)
        coder.encode(identifier,forKey: PropertyKey.identifier)
    }
    func turnOnAlarm() {
        turnOffAlarm()
        if week == 0{ // week == 0 说明不重复，只响一次
            self.addLocalNotification(-1)
            return
        }
        for i in 0...6 {
            if(1<<i & week) != 0{
                self.addLocalNotification(i)
            }
        }
    }
    func turnOffAlarm() {
        let notificationCenter = UNUserNotificationCenter.current()
        for i in 0...6 {
            notificationCenter.removePendingNotificationRequests(withIdentifiers:[identifier!+String(i)])
            turnOffTimer(i)
        }
        
    }
    func addLocalNotification(_ week:Int) {
        // get week and date String
        var weekString:String = ""
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .none
        dateFormatter.timeStyle = .short
        dateFormatter.locale = Locale(identifier: "en_US")
        let dateString = dateFormatter.string(from: alarmDate!)
        switch week {
        case 0:
            weekString = "Monday"
        case 1:
            weekString = "Tuesday"
        case 2:
            weekString = "Wednesday"
        case 3:
            weekString = "Thursday"
        case 4:
            weekString = "Friday"
        case 5:
            weekString = "Saturday"
        case 6:
            weekString = "Sunday"
        default:
            weekString = ""
        }
        
        
        // content
        let content = UNMutableNotificationContent()
        content.title = "Alarm"
        if weekString == ""{
            content.body = "No repeat at " + dateString
        }
        else{
            content.body = "Every " + weekString + " at " + dateString
        }
        content.sound = UNNotificationSound.defaultCritical
        
        if week == -1{ // 不重复，只响一次
            // Configure the recurring date.
            var dateComponents = DateComponents()
            dateComponents.calendar = Calendar.current
            // dateComponents.weekday = (week+2) % 7
            (dateComponents.hour,dateComponents.minute) = getHourAndMinute(dateString)
            dateComponents.second = 0
            
            // Create the trigger as a repeating event.
            let trigger = UNCalendarNotificationTrigger(
                     dateMatching: dateComponents, repeats:false)
            // Create the request
            let request = UNNotificationRequest(identifier: identifier! + "-1",content: content, trigger: trigger)
            // Schedule the request with the system.
            let notificationCenter = UNUserNotificationCenter.current()
            notificationCenter.add(request) { (error) in
               if error != nil {
                print(error!.localizedDescription)
               }
            }
            
            turnOnNextTimer(dayOfWeek(),false)
            
            return
        }
        
        // Configure the recurring date.
        var dateComponents = DateComponents()
        dateComponents.calendar = Calendar.current
        dateComponents.weekday = (week+2) % 7
        (dateComponents.hour,dateComponents.minute) = getHourAndMinute(dateString)
        dateComponents.second = 0
        
        // Create the trigger as a repeating event.
        let trigger = UNCalendarNotificationTrigger(
                 dateMatching: dateComponents, repeats: true)
        // Create the request
        let request = UNNotificationRequest(identifier: identifier! + String(week),content: content, trigger: trigger)
        // Schedule the request with the system.
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.add(request) { (error) in
           if error != nil {
            print(error!.localizedDescription)
           }
        }
        turnOnNextTimer(week)
    }
    func getHourAndMinute(_ dateString:String)->(Int,Int){
        let hourMinuteMStringList = dateString.split(separator: " ")
        let hourAndMinuteStringList = hourMinuteMStringList[0].split(separator: ":")
        let hourString = hourAndMinuteStringList[0]
        let minuteString = hourAndMinuteStringList[1]
        let MString = hourMinuteMStringList[1]
        var hour = 0
        var min = 0
        
        hour += Int(hourString)!
        min += Int(minuteString)!
        
        if MString == "PM"{
            if hour < 12{
                hour += 12
            }
        }
        return (hour,min)
    }
    func setTabel(_ table:AlarmTableViewController?=nil){
        self.table = table
    }
    func turnOnNextTimer(_ i:Int,_ repeats:Bool=true){
        let now = Date(timeIntervalSinceNow: 0)
        let nowDateFormatter = DateFormatter()
        nowDateFormatter.dateStyle = .none
        nowDateFormatter.timeStyle = .short
        nowDateFormatter.locale = Locale(identifier: "en_US")
        let nowString = nowDateFormatter.string(from: now)
        var nowHour = 0, nowMin = 0
        (nowHour,nowMin) = getHourAndMinute(nowString)
        
        let alarmDateFormatter = DateFormatter()
        alarmDateFormatter.dateStyle = .none
        alarmDateFormatter.timeStyle = .short
        alarmDateFormatter.locale = Locale(identifier: "en_US")
        let alarmString = alarmDateFormatter.string(from: alarmDate!)
        var alarmHour = 0, alarmMin = 0
        (alarmHour,alarmMin) = getHourAndMinute(alarmString)
        
        let todayOfWeek = dayOfWeek()
        var dayInterval = 0
        if todayOfWeek > i{
            dayInterval = 7
        }
        else if todayOfWeek == i{
            if (alarmHour < nowHour){
                dayInterval = 7
            }
            else if (alarmHour == nowHour){
                if(alarmMin < nowMin){
                    dayInterval = 7
                }
            }
        }
        dayInterval += (i-todayOfWeek)
        
        let secondInterval = dayInterval*86400 + (alarmHour-nowHour)*3600 + (alarmMin-nowMin)*60 - 30
        
        self.timers[i] = Timer.scheduledTimer(withTimeInterval: TimeInterval(secondInterval), repeats: false, block: { (timer) in
                self.showMotionViewController(i,repeats)
            })
    }
    func turnOnWeeklyTimer(_ i:Int){
        let secondsOfWeek = 86400*7
        self.timers[i] = Timer.scheduledTimer(withTimeInterval: TimeInterval(secondsOfWeek), repeats: false, block: { (timer) in
                self.showMotionViewController(i)
            })
    }
    func turnOffTimer(_ i:Int){
        self.timers[i].invalidate()
    }
    func showMotionViewController(_ i:Int,_ repeats:Bool = true){
        turnOffTimer(i)
        if repeats{
            turnOnWeeklyTimer(i)
        }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(identifier: "MotionViewController")

        secondVC.modalPresentationStyle = .fullScreen
        secondVC.modalTransitionStyle = .crossDissolve
            
        self.table!.present(secondVC, animated: true, completion: nil)
        
        if let secondVC = secondVC as? MotionViewController{
            secondVC.doneButton.isEnabled = false
            secondVC.doneButton.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
            secondVC.motionModeLabel.text = self.mode! + " NOW !"
            secondVC.motionTimesLabel.text = "0"
            secondVC.motionTimesProgressView.setProgress(0.0, animated: true)
            secondVC.times = self.times
            secondVC.mode = self.mode!
            secondVC.setGestureClassifier()
        }
    }
    func dayOfWeek() -> Int {
        let interval = DateInterval(start: Date(timeIntervalSince1970: 0), end: Date(timeIntervalSinceNow: 0)).duration
        let days = Int(interval / 86400)
        return (days-4) % 7
    }
}
