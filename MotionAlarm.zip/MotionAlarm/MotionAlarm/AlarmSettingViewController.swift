//
//  ViewController.swift
//  MotionAlarm
//
//  Created by strivin on 2020/12/11.
//

import UIKit
import os.log

class AlarmSettingViewController: UIViewController {
//MARK:-properties
    @IBOutlet var alarmDatePicker: UIDatePicker! // 时间选择器
    
    @IBOutlet var weekButtons: [UIButton]! // 星期重复选择按钮
    
    @IBOutlet var motionModePicker: UIPickerView! // 运动模式选择器
    
    @IBOutlet var motionTimesLabel: UILabel! // 运动重复次数标签
    
    @IBOutlet var motionTimesSlider: UISlider! // 运动重复次数滑条
    
    @IBOutlet var tipsTextField: UITextField! // 提示文本框
    
    @IBOutlet var saveButton: UIBarButtonItem! // 保存按钮
    var alarm:AlarmData? // 当前设置闹钟
    let motionMode:[String] = ["chop","drive","shake"] // 运动模式字符串
//MARK:-override funcs
    override func viewDidLoad() {
        super.viewDidLoad()
        initOutlets()
        setupAlarm()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
            os_log("The save button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        } // 点击save按钮后返回
        // 修改模式
        if let alarm = alarm{
            alarm.alarmDate = alarmDatePicker.date
            alarm.tipText = tipsTextField.text
            alarm.week = getWeek()
            alarm.mode = motionMode[motionModePicker.selectedRow(inComponent: 0)]
            alarm.times = Int(motionTimesSlider.value)
        }
        // 添加模式
        else{
            let date = alarmDatePicker.date
            let tip = tipsTextField.text
            let alarmOn = false
            let week = getWeek()
            let mode = motionMode[motionModePicker.selectedRow(inComponent: 0)]
            let times = Int(motionTimesSlider.value)
            let identifier = Date(timeIntervalSinceNow: 0).description
            alarm = AlarmData(alarmDate: date, tipText: tip, alarmOn: alarmOn, week: week, mode: mode, times: times, identifier: identifier)
        }
    }
//MARK:-action funcs
    @IBAction func weekButtonClicked(_ sender: UIButton) {
        setupWeekButton(sender, true,true)
    }
    @IBAction func motionTimesSliderChanged(_ sender: UISlider) {
        let times = Int(sender.value)
        motionTimesLabel.text = String(times)
    }
    //MARK:-other funcs
    func initOutlets(){
        // init delegate
        motionModePicker.delegate = self
        tipsTextField.delegate = self
        // init alarmDatePicker
        alarmDatePicker.date = Date(timeIntervalSinceNow: 0)
        // init weekButtons
        for b in weekButtons{
            setupWeekButton(b,false)
        }
        // init motionModePicker(in extension)
        // init motionTimesLabel
        motionTimesLabel.text = "20"
        // init motionTimesSlider
        motionTimesSlider.minimumValue = 10
        motionTimesSlider.maximumValue = 100
        motionTimesSlider.value = 20
        motionTimesSlider.isContinuous = true
        // init navagationItem
        navigationItem.title = "Alarm Setting"
    }
    func setupAlarm(){
        if let alarm = alarm{
            alarmDatePicker.date = alarm.alarmDate!
            for i in 0...6{
                if (1<<i & alarm.week) != 0{
                    setupWeekButton(weekButtons[i], true)
                }
                else{
                    setupWeekButton(weekButtons[i], false)
                }
            }
            for (i,mode) in motionMode.enumerated(){
                if mode == alarm.mode{
                    motionModePicker.selectRow(i, inComponent: 0, animated: true)
                }
            }
            motionTimesLabel.text = String(alarm.times)
            motionTimesSlider.value = Float(alarm.times)
            tipsTextField.text = alarm.tipText
            navigationItem.title = alarm.tipText
        }
    }
    func setupWeekButton(_ button:UIButton,_ set:Bool, _ reverse:Bool = false){
        
        if reverse{
            if button.titleColor(for: .normal) == #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1){
                button.setTitleColor(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1), for: .normal)
            }
            else if button.titleColor(for: .normal) == #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1) {
                button.setTitleColor(#colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1), for: .normal)
            }
        }
        else{
            if set{
                button.setTitleColor(#colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1), for: .normal)
            }
            else{
                button.setTitleColor(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1), for: .normal)
            }
        }
    }
    func getWeek()->Int{
        var week = 0
        for (i,b) in weekButtons.enumerated(){
            if b.titleColor(for: .normal) == #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1){
                week += (1<<i)
            }
        }
        return week
    }
}
//MARK:-extension for TextField
extension AlarmSettingViewController:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // 接受到回车，撤销自己的第一响应
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        navigationItem.title = textField.text
        saveButton.isEnabled = true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        saveButton.isEnabled = false // 开始输入，此时不可保存
    }
}
//MARK:-extension for PickerView
extension AlarmSettingViewController:UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // 只有一栏
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return motionMode.count
    }
    
}
extension AlarmSettingViewController:UIPickerViewDelegate{
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return motionMode[row]
    }
}
