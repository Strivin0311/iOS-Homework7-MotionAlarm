//
//  MotionViewController.swift
//  MotionAlarm
//
//  Created by strivin on 2020/12/14.
//

import UIKit
import Vision
import CoreMotion
import CoreML

class MotionViewController: UIViewController {
//MARK:-IBOutlet var
    @IBOutlet var motionModeLabel: UILabel!
    
    @IBOutlet var motionTimesLabel: UILabel!
    
    @IBOutlet var motionTimesProgressView: UIProgressView!
    
    @IBOutlet var doneButton: UIButton!
//MARK:-classification var
    var clf: GestureClassifier! // 分类器
    var clfOutput: GestureClassifierOutput! // 分类结果
    let motionManager = CMMotionManager() // 动作管理器
    let queue = OperationQueue() // 操作队列
    let feaNum = 6 // 特征个数
    let winSize = 20 // 窗口总大小
    let winLen = 5 // 窗口长度
    let winNum = 4 // 窗口个数
    let bufSize = 35 // 缓存大小
    var bufIndex = 0 // 缓存索引
    var feaBytes = MemoryLayout<Double>.stride
    var winLenBytes = MemoryLayout<Double>.stride
    var winSizeBytes = MemoryLayout<Double>.stride
    var bufArray: MLMultiArray?
    var inputArray:MLMultiArray?
//MARK:-other var
    var count = 0
    var times = 10
    var mode = ""
//MARK:-overrider funcs
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
//MARK:-other funcs
    func setGestureClassifier(){
        // 创建分类器
        do {
            clf = try GestureClassifier(configuration: MLModelConfiguration())
        } catch {
            fatalError("wrong clf!")
        }
        // 设置动作管理器
        motionManager.deviceMotionUpdateInterval = 0.05 // 响应时间间隔
        motionManager.startDeviceMotionUpdates(using: .xArbitraryZVertical,to: queue,withHandler: self.handler)
        // 设置Bytes
        feaBytes = feaNum * MemoryLayout<Double>.stride
        winLenBytes = winLen * feaBytes
        winSizeBytes = winSize * feaBytes
        // 设置Array
        bufArray = try? MLMultiArray(shape: [1, bufSize, feaNum] as [NSNumber],dataType:.double)
        inputArray = try? MLMultiArray(shape: [1, winSize, feaNum] as [NSNumber],dataType:.double)
    }
    func handler(_ data: CMDeviceMotion?, _ error: Error?){
        guard let data = data else {
            print(error?.localizedDescription)
            return
        }
        
        for i in 0...winSize {
            let idx = bufIndex + i
            if idx >= bufSize {
                continue
            }
            // 加入角速度
            bufArray?[[0, idx, 0] as [NSNumber]] = NSNumber(value: data.rotationRate.x)
            bufArray?[[0, idx, 1] as [NSNumber]] = NSNumber(value: data.rotationRate.y)
            bufArray?[[0, idx, 2] as [NSNumber]] = NSNumber(value: data.rotationRate.z)
            // 加入线加速度
            bufArray?[[0, idx, 3] as [NSNumber]] = NSNumber(value: data.userAcceleration.x)
            bufArray?[[0, idx, 4] as [NSNumber]] = NSNumber(value: data.userAcceleration.y)
            bufArray?[[0, idx, 5] as [NSNumber]] = NSNumber(value: data.userAcceleration.z)
        }
        bufIndex = (bufIndex + 1) % winSize
        
        if (bufIndex == 0 && bufIndex + winLen <= winSize) {
            let winIndex = bufIndex / winLen
            memcpy(inputArray?.dataPointer,bufArray?.dataPointer.advanced(by: winIndex * winLenBytes),winSizeBytes)

            var clfInput: GestureClassifierInput! = nil
            if clfOutput != nil {
                clfInput = GestureClassifierInput(
                    features: inputArray!,
                    hiddenIn: clfOutput.hiddenOut,
                    cellIn: clfOutput.cellOut
                )
            }
            else {
                clfInput = GestureClassifierInput(features: inputArray!)
            }
            
            do {
                clfOutput = try clf.prediction(input: clfInput)
            } catch {
                fatalError("wrong prediction!")
            }
            
            DispatchQueue.main.async {
                let activity = self.clfOutput.activity.split(separator: "_")[0]
                if activity == self.mode{
                    self.count += 1
                    if (self.count >= self.times){
                        self.doneButton.isEnabled = true
                        self.doneButton.backgroundColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
                        self.count = self.times
                    }
                    self.motionTimesLabel.text = String(self.count)
                    self.motionTimesProgressView.setProgress(Float(self.count/self.times), animated: true)
                }
            }
        }
    }
}
