//
//  AlarmTableViewCell.swift
//  MotionAlarm
//
//  Created by strivin on 2020/12/13.
//

import UIKit

class AlarmTableViewCell: UITableViewCell {
//MARK:-properties
    @IBOutlet var tipLabel: UILabel! // 提示标签
    
    @IBOutlet var alarmTimeLabel: UILabel! // 闹钟时间标签
    
    @IBOutlet var weekLabels: [UILabel]! // 星期重复标签
    
    @IBOutlet var alarmSwitch: UISwitch! // 闹钟开关
    
    var alarm: AlarmData? // 闹钟数据
//MARK:-override funcs
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        tipLabel.layer.cornerRadius = 10.0 // 设置圆角
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
//MARK:-action funcs
    @IBAction func switchClicked(_ sender: UISwitch) {
        if let tempAlarm = self.alarm {
            if sender.isOn {
                tempAlarm.alarmOn = true
                tempAlarm.turnOnAlarm()
            } else {
                tempAlarm.alarmOn = false
                tempAlarm.turnOffAlarm()
            }
        }
    }
//MARK:-setter funcs
    func setAlarm(_ alarm:AlarmData) {
        self.alarm = alarm
        // set timeLabel
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        if let date = alarm.alarmDate {
            self.alarmTimeLabel.text = dateFormatter.string(from: date as Date)
        }
        // set tipLabel
        if let text = alarm.tipText{
            self.tipLabel.text = text
        }
        // set weekLabels
        for i in 0...6 {
            if (1 << i & alarm.week) != 0 {
                weekLabels[i].textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            }
            else{
                weekLabels[i].textColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
            }
        }
        // set alarmSwitch
        self.alarmSwitch.isOn = alarm.alarmOn
        if alarm.alarmOn{
            alarm.turnOnAlarm()
        }
        else{
            alarm.turnOffAlarm()
        }
    }
}
